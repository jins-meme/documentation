﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Networking;
using Windows.Networking.Sockets;
using Windows.Storage.Streams;
using System.Text;
using System.Diagnostics;
using System.Threading.Tasks;
using Windows.Storage;

/// <summary>
/// MemeTcpClientRuntime is a Windows Runtime Component which manages tcp socket connection between JINS MEME Data Logger.
/// </summary>
namespace MemeTcpClientRuntime
{
    /// <summary>
    ///  Index for accessing JINS MEME data array when Standard momde.
    /// </summary>
    public enum StdIndexes { 
        /// <summary>
        /// Artifact
        /// </summary>
        Arti = 0,
        /// <summary>
        /// Data id in order from 0.
        /// </summary>
        Num,
        /// <summary>
        /// Captured date
        /// </summary>
        Date,
        /// <summary>
        /// Acceleration X(raw value, not offset)
        /// </summary>
        AccX,
        /// <summary>
        /// Acceleration Y(raw value, not offset)
        /// </summary>
        AccY,
        /// <summary>
        /// Acceleration Z(raw value, not offset)
        /// </summary>
        AccZ,
        /// <summary>
        /// EOG Left 1
        /// </summary>
        EogL1,
        /// <summary>
        /// EOG Right 1
        /// </summary>
        EogR1,
        /// <summary>
        /// EOG Left 2
        /// </summary>
        EogL2,
        /// <summary>
        /// EOG Right 2
        /// </summary>
        EogR2,
        /// <summary>
        /// EOG Horizontal 1
        /// </summary>
        EogH1,
        /// <summary>
        /// EOG Horizontal 2
        /// </summary>
        EogH2,
        /// <summary>
        /// EOG Vertical 1
        /// </summary>
        EogV1,
        /// <summary>
        /// EOG Vertical 2
        /// </summary>
        EogV2 
    }

    /// <summary>
    ///  Index for accessing JINS MEME data array when Full momde.
    /// </summary>
    public enum FullIndexes {
        /// <summary>
        /// Artifact
        /// </summary>
        Arti = 0, 
        /// <summary>
        /// data No.
        /// </summary>
        Num,
        /// <summary>
        /// Captured date
        /// </summary>
        Date,
        /// <summary>
        /// Acceleration X(raw value, not offset)
        /// </summary>
        AccX,
        /// <summary>
        /// Acceleration Y(raw value, not offset)
        /// </summary>
        AccY,
        /// <summary>
        /// Acceleration Z(raw value, not offset)
        /// </summary>
        AccZ,
        /// <summary>
        /// Gyro sensored value X
        /// </summary>
        GyroX,
        /// <summary>
        /// Gyro sensored value Y
        /// </summary>
        GyroY,
        /// <summary>
        /// Gyro sensored value Z
        /// </summary>
        GyuroZ,
        /// <summary>
        /// EOG Left
        /// </summary>
        EogL,
        /// <summary>
        /// EOG Right
        /// </summary>
        EogR,
        /// <summary>
        /// EOG Horizontal
        /// </summary>
        EogH,
        /// <summary>
        /// EOG Vertical
        /// </summary>
        EogV 
    }
    
    /// <summary>
    ///  Index for accessing JINS MEME data array when Quaternion momde.
    /// </summary>
    public enum QuatIndexes {
        /// <summary>
        /// Artifact
        /// </summary>
        Arti = 0,
        /// <summary>
        /// data No.
        /// </summary>
        Num,
        /// <summary>
        /// Captured date
        /// </summary>
        Date,
        /// <summary>
        /// Quaternion W component
        /// </summary>
        QuatW,
        /// <summary>
        /// Quaternion X component
        /// </summary>
        QuatX,
        /// <summary>
        /// Quaternion Y component
        /// </summary>
        QuatY,
        /// <summary>
        /// Quaternion Z component
        /// </summary>
        QuatZ 
    }
    
    /// <summary>
    /// ReadMode is a relevant with "Mode Select" on JINS MEME Data Logger, which has 3 mode as listed below,
    /// <list type="bullet">
    /// <item>
    /// <description>Standard: correspond to "Standard" mode.</description>
    /// </item>
    /// <item>
    /// <description>Full: correspond to "Full" mode.</description>
    /// </item>
    /// <item>
    /// <description>Quaternion: correspond to "Quaternion" mode.</description>
    /// </item>
    /// </list>
    /// </summary>
    public enum ReadMode { 
        /// <summary>
        /// Standard mode
        /// </summary>
        Standard,
        /// <summary>
        /// Full mode
        /// </summary>
        Full,
        /// <summary>
        /// Quaternion mode
        /// </summary>
        Quatenion 
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="elems">An returned array from tcp socket. Each element is retrieved with StdIndexes/FullIndexes/QuatIndexes.</param>
    public delegate void DataReceivedHandler([ReadOnlyArray] string[] elems);

    /// <summary>
    ///  MemeTcpCient is a utility class for communicating with JINS MEME ES AP using tcp socket.
    /// </summary>
    public sealed class MemeTcpClient
    {
        // class properties
        StreamSocket clientSocket;
        ReadMode readMode = ReadMode.Standard;  // default readmode
        int elemCnt = 0;

        /// <summary>
        /// An DataReceived Handler that receives string[] values where each element is retrieved with StdIndexes/FullIndexes/QuatIndexes.
        /// </summary>
        public event DataReceivedHandler onDataReceived;

        // for csv output
        bool needCsv = true;  // true if you need csv output
        String csvStr = "";

        static int buffSize = 1024;
        static string[] lfCode = new string[] { "\r\n" };

        /// <summary>
        /// Just instanciate MemeTcpCient object.
        /// </summary>
        public MemeTcpClient() {}

        /// <summary>
        /// Establish tcp socket connection bwteween host.
        /// </summary>
        /// <param name="hostName">HostName object that contains Host IP address.</param>
        /// <param name="port">Port No. host is sending data to.</param>
        /// <param name="mode">ReadMode correspond with "Mode Select" value on JINS MEME Data Logger.</param>
        public async void connect(HostName hostName, String port, ReadMode mode)
        {
            this.csvStr = "";
            this.clientSocket = new StreamSocket();
            this.readMode = mode;
            await clientSocket.ConnectAsync(hostName, port);
            Debug.WriteLine("Connected");

            switch (mode)
            {
                case ReadMode.Standard:
                    elemCnt = 14;
                    break;
                case ReadMode.Full:
                    elemCnt = 13;
                    break;
                case ReadMode.Quatenion:
                    elemCnt = 7;
                    break;
                default: break;
            }

            // read bytes
            while (this.clientSocket != null)
            {
                byte[] asciiBytes = await ReadAsync(this.clientSocket);
                if (asciiBytes == null) continue;

                Encoding enc = Encoding.GetEncoding("us-ascii");
                string dataStr = enc.GetString(asciiBytes, 0, asciiBytes.Length);
                if (dataStr.Length <= 0) { continue; }

                string[] lines = dataStr.Split(lfCode, StringSplitOptions.RemoveEmptyEntries);
                if (lines.Count() <= 0) { continue; }

                foreach (string elemLine in lines)
                {
                    //Debug.WriteLine(elemLine);
                    this.csvStr += elemLine;
                    this.csvStr += "\n";

                    string[] elems = elemLine.Split(new string[] { "," }, StringSplitOptions.None);
                    if (elems.Count() == this.elemCnt)
                    {
                        if (this.onDataReceived != null)
                        {
                            this.onDataReceived(elems);
                        }
                    }
                    else
                    {
                        Debug.WriteLine("some element lacks: " + elemLine);
                    }
                }
            }
        }

        /// <summary>
        /// Disconnect tcp socket connection.
        /// </summary>
        public void disconnect() {

            if (this.clientSocket == null) { return; }

            this.clientSocket.Dispose();
            this.clientSocket = null;

            if (this.needCsv)
            {
                this.writeCsv();
            }
        }

        static async Task<byte[]> ReadAsync(StreamSocket socket)
        {
            IBuffer buffer = new byte[buffSize].AsBuffer();
            try
            {
                await socket.InputStream.ReadAsync(
                        buffer, buffer.Capacity, InputStreamOptions.Partial);
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
                return null;
            }
            return buffer.ToArray();
        }

        async void writeCsv()
        {
            // Prepend element names for the first line of csv
            if (csvStr == null || csvStr.Length <= 0) return;

            String elemNames = "";
            switch (readMode)
            {
                case ReadMode.Standard:
                    elemNames = String.Join(",", Enum.GetNames(typeof(StdIndexes)));
                    break;
                case ReadMode.Full:
                    elemNames = String.Join(",", Enum.GetNames(typeof(FullIndexes)));
                    break;
                case ReadMode.Quatenion:
                    elemNames = String.Join(",", Enum.GetNames(typeof(QuatIndexes)));
                    break;
                default: break;
            }

            elemNames += "\n";
            csvStr = elemNames + csvStr;

            // Output csv to Picture folder
            StorageFile memeFile = await KnownFolders.PicturesLibrary.CreateFileAsync("memedata.csv", CreationCollisionOption.ReplaceExisting);
            await Windows.Storage.FileIO.WriteTextAsync(memeFile, csvStr);
        }

    }
}
